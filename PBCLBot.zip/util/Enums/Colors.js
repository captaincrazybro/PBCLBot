module.exports = class Colors {}

let Colors = module.exports;

Colors.ERROR = "RED";
Colors.INFO = "BLUE";
Colors.WARN = "GOLD";
Colors.SUCCESS = "DARK_GREEN";