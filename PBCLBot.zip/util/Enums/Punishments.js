module.exports = class Punishments {}

let Punishments = module.exports;

Punishments.WARN = 'WARN';
Punishments.MUTE = 'MUTE';
Punishments.KICK = 'KICK';
Punishments.BAN = 'BAN';
Punishments.BLACKLIST = 'BLACKLIST';
Punishments.REPORT = 'REPORT';
Punishments.UNWARN = 'UNWARN';
Punishments.UNMUTE = 'UNMUTE';
Punishments.UNBAN = 'UNBAN';
Punishments.UNBLACKLIST = 'UNBLACKLIST';
Punishments.UNREPORT = 'UNREPORT';